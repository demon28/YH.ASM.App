<template>
	<view class="iconfont con_coinpurse_line icon-icon_coinpurse_line"></view>
</template>

<script>
	import '@/static/iconfont/iconfont.css' //使用字体图标
	import '@/static/js/constant.js'
	import '@/static/css/reset.scss'
	export default {
		data() {
			return {

			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>
<style lang='scss'>
	.iconfont{
		display: inline-block;
		color: #666;
		font-size: 24px;
	}
</style>
